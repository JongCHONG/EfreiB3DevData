import React from "react";

const Button = ({ text }) => {
  return (
    <div>
      <button type="submit">{text}</button>
    </div>
  );
};

export default Button;
